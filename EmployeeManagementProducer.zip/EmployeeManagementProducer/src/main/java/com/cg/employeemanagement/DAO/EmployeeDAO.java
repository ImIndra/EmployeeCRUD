package com.cg.employeemanagement.DAO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Repository;

import com.cg.employeemanagement.model.Employee;

@Repository
public class EmployeeDAO {

	public boolean addEmployee(Employee employee) throws IOException {
		FileInputStream fis = new FileInputStream(
				new File("C:\\Desktop\\STSWorkspace\\EmployeeManagementProducer\\src\\main\\resources\\Database.xlsx"));
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheetAt(0);
		Object[][] employeeDetails = {
				{ employee.getEmpId(), employee.getFirstName(), employee.getLastName(), employee.getAddress() } };
		int rowFound = 0;
		String employeeId = employee.getEmpId();
		for (Row row : sheet) {
			for (Cell cell : row) {
				if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
					if (cell.getStringCellValue().equals(employeeId)) {
						rowFound = row.getRowNum();
						System.out.println("Employee Data found in " + rowFound);
					}
				}
			}
		}
		if (rowFound == 0) {
			int rowNum = sheet.getLastRowNum() + 1;
			System.out.println("Creating excel");

			for (Object[] emp : employeeDetails) {
				Row row = sheet.createRow(rowNum);
				int colNum = 0;
				for (Object field : emp) {
					Cell cell = row.createCell(colNum++);
					if (field instanceof String) {
						cell.setCellValue((String) field);
					}
				}
			}
			System.out.println("Employee inserted in Database");
			try {
				FileOutputStream outputStream = new FileOutputStream(
						"C:\\Desktop\\STSWorkspace\\EmployeeManagementProducer\\src\\main\\resources\\Database.xlsx");
				workbook.write(outputStream);
				workbook.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			return true;
		} else {
			try {
				FileOutputStream outputStream = new FileOutputStream(
						"C:\\Desktop\\STSWorkspace\\EmployeeManagementProducer\\src\\main\\resources\\Database.xlsx");
				workbook.write(outputStream);
				workbook.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.out.println("Employee with same Employee Id already present in Database");
			return false;
		}
	}

	@SuppressWarnings("deprecation")
	public Employee getEmployeeById(String empId) throws IOException {
		FileInputStream fis = new FileInputStream(
				new File("C:\\Desktop\\STSWorkspace\\EmployeeManagementProducer\\src\\main\\resources\\Database.xlsx"));
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheetAt(0);
		Row r = sheet.getRow(0);
		String employeeId = empId;
		int rowFound = 0;
		for (Row row : sheet) {
			for (Cell cell : row) {
				if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
					if (cell.getStringCellValue().equals(employeeId)) {
						rowFound = row.getRowNum();
						System.out.println("Employee Data found in " + rowFound);
					}
				}
			}
		}
		Row currentRow = sheet.getRow(rowFound);
		Employee employee = new Employee();
		employee.setEmpId(currentRow.getCell(0).getStringCellValue());
		employee.setFirstName(currentRow.getCell(1).getStringCellValue());
		employee.setLastName(currentRow.getCell(2).getStringCellValue());
		employee.setAddress(currentRow.getCell(3).getStringCellValue());

		try {
			FileOutputStream outputStream = new FileOutputStream(
					"C:\\Desktop\\STSWorkspace\\EmployeeManagementProducer\\src\\main\\resources\\Database.xlsx");
			workbook.write(outputStream);
			workbook.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Done");
		return employee;
	}

	public boolean updateEmployee(Employee employee) throws IOException {
		FileInputStream fis = new FileInputStream(
				new File("C:\\Desktop\\STSWorkspace\\EmployeeManagementProducer\\src\\main\\resources\\Database.xlsx"));
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheetAt(0);
		String employeeId = employee.getEmpId();
		int rowFound = 0;
		for (Row row : sheet) {
			for (Cell cell : row) {
				if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
					if (cell.getStringCellValue().equals(employeeId)) {
						rowFound = row.getRowNum();
						System.out.println("Employee Data found in " + rowFound);
					}
				}
			}
		}
		if (rowFound == 0) {
			try {
				FileOutputStream outputStream = new FileOutputStream(
						"C:\\Desktop\\STSWorkspace\\EmployeeManagementProducer\\src\\main\\resources\\Database.xlsx");
				workbook.write(outputStream);
				workbook.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			System.out.println("Update Unsuccessful");
			return false;
		} else {
			XSSFRow row = sheet.getRow(rowFound);
			// XSSFCell cell1 = row.getCell(0);
			XSSFCell cell2 = row.getCell(1);
			XSSFCell cell3 = row.getCell(2);
			XSSFCell cell4 = row.getCell(3);
			// cell1.setCellValue(employee.getEmpId());
			cell2.setCellValue(employee.getFirstName());
			cell3.setCellValue(employee.getLastName());
			cell4.setCellValue(employee.getAddress());

			try {
				FileOutputStream outputStream = new FileOutputStream(
						"C:\\Desktop\\STSWorkspace\\EmployeeManagementProducer\\src\\main\\resources\\Database.xlsx");
				workbook.write(outputStream);
				workbook.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			System.out.println("Update completed");
			return true;
		}

	}

	public boolean deleteEmployee(String empId) throws IOException {
		FileInputStream fis = new FileInputStream(
				new File("C:\\Desktop\\STSWorkspace\\EmployeeManagementProducer\\src\\main\\resources\\Database.xlsx"));
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheetAt(0);
		String employeeId = empId;
		int rowFound = 0;
		for (Row row : sheet) {
			for (Cell cell : row) {
				if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
					if (cell.getStringCellValue().equals(employeeId)) {
						rowFound = row.getRowNum();
						System.out.println("Employee Data found in " + rowFound);
					}
				}
			}
		}
		if (rowFound == 0) {
			try {
				FileOutputStream outputStream = new FileOutputStream(
						"C:\\Desktop\\STSWorkspace\\EmployeeManagementProducer\\src\\main\\resources\\Database.xlsx");
				workbook.write(outputStream);
				workbook.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			System.out.println("Delete Unsuccessful");
			return false;
		} else {
			XSSFRow row = sheet.getRow(rowFound);
			sheet.removeRow(row);
			int lastIndex = sheet.getLastRowNum();
			sheet.shiftRows(rowFound + 1, lastIndex, -1);
			try {
				FileOutputStream outputStream = new FileOutputStream(
						"C:\\Desktop\\STSWorkspace\\EmployeeManagementProducer\\src\\main\\resources\\Database.xlsx");
				workbook.write(outputStream);
				workbook.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			System.out.println("Deleted Employee Data");
			return true;

		}

	}

}
