package com.cg.employeemanagement.endpoints;

import java.io.IOException;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.capg.employeemanagement.AddEmployeeRequest;
import com.capg.employeemanagement.AddEmployeeResponse;
import com.capg.employeemanagement.DeleteEmployeeRequest;
import com.capg.employeemanagement.DeleteEmployeeResponse;
import com.capg.employeemanagement.EmployeeInfo;
import com.capg.employeemanagement.GetEmployeeByIdRequest;
import com.capg.employeemanagement.GetEmployeeByIdResponse;
import com.capg.employeemanagement.ServiceStatus;
import com.capg.employeemanagement.UpdateEmployeeRequest;
import com.capg.employeemanagement.UpdateEmployeeResponse;
import com.cg.employeemanagement.model.Employee;
import com.cg.employeemanagement.service.EmployeeService;

@Endpoint
public class EmployeeEndpoint {

	private static final String NAMESPACE_URI = "http://www.capgemini.com/employee-ws";

	@Autowired
	private EmployeeService employeeService;

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "addEmployeeRequest")
	@ResponsePayload
	public AddEmployeeResponse addEmployee(@RequestPayload AddEmployeeRequest request) throws IOException {
		AddEmployeeResponse response = new AddEmployeeResponse();
		ServiceStatus serviceStatus = new ServiceStatus();
		Employee employee = new Employee();
		employee.setEmpId(request.getEmpId());
		employee.setFirstName(request.getFirstName());
		employee.setLastName(request.getLastName());
		employee.setAddress(request.getAddress());
		System.out.println(
				employee.getEmpId() + employee.getFirstName() + employee.getLastName() + employee.getAddress());
		boolean flag = employeeService.addEmployee(employee);
		if (flag == false) {
			serviceStatus.setStatusCode("CONFLICT");
			serviceStatus.setMessage(
					"Employee with Employee Id: " + employee.getEmpId() + " is already present in database");
			response.setServiceStatus(serviceStatus);
		} else {
			serviceStatus.setStatusCode("SUCCESS");
			serviceStatus.setMessage("Employee with Employee Id: " + employee.getEmpId() + " is inserted in database");
			response.setServiceStatus(serviceStatus);
		}
		return response;
	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "getEmployeeByIdRequest")
	@ResponsePayload
	public GetEmployeeByIdResponse getEmployeeById(@RequestPayload GetEmployeeByIdRequest request)
			throws BeansException, IOException {
		GetEmployeeByIdResponse response = new GetEmployeeByIdResponse();
		EmployeeInfo employeeInfo = new EmployeeInfo();
		BeanUtils.copyProperties(employeeService.getEmployeeById(request.getEmpId()), employeeInfo);
		response.setEmployeeInfo(employeeInfo);
		return response;
	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "updateEmployeeRequest")
	@ResponsePayload
	public UpdateEmployeeResponse updateArticle(@RequestPayload UpdateEmployeeRequest request) throws IOException {
		Employee employee = new Employee();
		System.out.println("In  controller");
		// BeanUtils.copyProperties(request.getArticleInfo(), employee);

		employee.setEmpId(request.getEmployeeInfo().getEmpId());
		employee.setFirstName(request.getEmployeeInfo().getFirstName());
		employee.setLastName(request.getEmployeeInfo().getLastName());
		employee.setAddress(request.getEmployeeInfo().getAddress());
		boolean flag = employeeService.updateEmployee(employee);
		ServiceStatus serviceStatus = new ServiceStatus();
		if (flag == false) {
			serviceStatus.setStatusCode("FAIL");
			serviceStatus
					.setMessage("Employee with Employee Id: " + employee.getEmpId() + " is not updated in database");
		} else {
			serviceStatus.setStatusCode("SUCCESS");
			serviceStatus.setMessage("Employee with Employee Id: " + employee.getEmpId() + " is Updated Successfully");
		}
		UpdateEmployeeResponse response = new UpdateEmployeeResponse();
		response.setServiceStatus(serviceStatus);
		return response;
	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "deleteEmployeeRequest")
	@ResponsePayload
	public DeleteEmployeeResponse deleteArticle(@RequestPayload DeleteEmployeeRequest request) throws IOException {
		boolean flag = employeeService.deleteEmployee(request.getEmpId());
		ServiceStatus serviceStatus = new ServiceStatus();
		if (flag == false) {
			serviceStatus.setStatusCode("FAIL");
			serviceStatus
					.setMessage("Employee with Employee Id: " + request.getEmpId() + " is not present in database");
		} else {

			serviceStatus.setStatusCode("SUCCESS");
			serviceStatus.setMessage("Employee with Employee Id: " + request.getEmpId() + " is successfully removed");
		}
		DeleteEmployeeResponse response = new DeleteEmployeeResponse();
		response.setServiceStatus(serviceStatus);
		return response;
	}
}