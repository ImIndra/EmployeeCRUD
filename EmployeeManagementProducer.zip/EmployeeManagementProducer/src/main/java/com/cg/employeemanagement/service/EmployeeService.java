package com.cg.employeemanagement.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employeemanagement.DAO.EmployeeDAO;
import com.cg.employeemanagement.model.Employee;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeDAO employeeDAO;

	public boolean deleteEmployee(String empId) throws IOException {
		boolean value = employeeDAO.deleteEmployee(empId);
		return value;
	}

	public boolean addEmployee(Employee employee) throws IOException {
		boolean value = employeeDAO.addEmployee(employee);
		return value;
	}

	public Employee getEmployeeById(String empId) throws IOException {
		Employee employee = employeeDAO.getEmployeeById(empId);
		return employee;
	}

	public boolean updateEmployee(Employee employee) throws IOException {
		boolean value = employeeDAO.updateEmployee(employee);
		return value;
	}
}
